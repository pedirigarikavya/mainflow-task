package forms;

public class Main {
    public static void main(String[] args) {
        new AddProductForm(); // or AddBuyerForm / DeleteProductForm / DeleteBuyerForm
    }
}