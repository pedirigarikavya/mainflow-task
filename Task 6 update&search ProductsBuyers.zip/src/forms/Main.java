package forms;

public class Main {
    public static void main(String[] args) {
        new UpdateProductForm();
        new UpdateBuyerForm();
        new SearchProductForm();
        new SearchBuyerForm();
    }
}