package forms;
import db.DBConnection;
import java.sql.*;
import javax.swing.*;

public class AddProductForm extends JFrame {
    JTextField nameField, categoryField, priceField, quantityField;
    JTextArea descriptionArea;
    JButton addButton;

    public AddProductForm() {
        setTitle("Add Product");
        setSize(300, 400);
        setLayout(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(10, 10, 100, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(120, 10, 150, 25);
        add(nameField);

        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setBounds(10, 50, 100, 25);
        add(categoryLabel);

        categoryField = new JTextField();
        categoryField.setBounds(120, 50, 150, 25);
        add(categoryField);

        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setBounds(10, 90, 100, 25);
        add(priceLabel);

        priceField = new JTextField();
        priceField.setBounds(120, 90, 150, 25);
        add(priceField);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setBounds(10, 130, 100, 25);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setBounds(120, 130, 150, 25);
        add(quantityField);

        JLabel descLabel = new JLabel("Description:");
        descLabel.setBounds(10, 170, 100, 25);
        add(descLabel);

        descriptionArea = new JTextArea();
        descriptionArea.setBounds(120, 170, 150, 60);
        add(descriptionArea);

        addButton = new JButton("Add Product");
        addButton.setBounds(80, 250, 120, 30);
        add(addButton);

        addButton.addActionListener(e -> addProduct());

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void addProduct() {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(
                "INSERT INTO products (name, category, price, quantity, description) VALUES (?, ?, ?, ?, ?)")) {
            stmt.setString(1, nameField.getText());
            stmt.setString(2, categoryField.getText());
            stmt.setDouble(3, Double.parseDouble(priceField.getText()));
            stmt.setInt(4, Integer.parseInt(quantityField.getText()));
            stmt.setString(5, descriptionArea.getText());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Product added successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}